# Polandball 3Dモデル・動き部分（原文のまま）

このフォルダのTypeScriptファイルは、アップロードされたZIPから変更せずに抽出したものです。

- `src/graphics/countryballMesh.ts`: Polandballの3D形状、旗テクスチャ、目、表情、アクセサリを生成・管理するモデル部分。
- `src/physics/physicsEngine.ts`: 重力、移動、加速、摩擦、ジャンプ、ダッシュ、衝突、リスポーンなどの物理移動部分。
- `src/game/GameEngine.ts`: 物理状態を3Dモデルへ反映するゲームループ、向き、ホップ、前傾、左右の揺れ、つぶれ・伸びのアニメーション部分を含む統合部分。
- `src/types/game.ts`: 上記ファイルが参照する型定義。

コード本体は編集していません。
